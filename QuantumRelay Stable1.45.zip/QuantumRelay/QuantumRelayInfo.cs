namespace QuantumRelay
{
    internal static class QuantumRelayInfo
    {
        internal const string ModName = "Quantum Relay";
        internal const string Version = "1.1.0-alpha4";
        internal const string Developer = "SockedRooster";
        internal const string Company = "RoosterWorks";
        internal const string License = "MIT";
        internal const string Tagline = "True CommNet Routing Through Wormholes";
    }
}
